<?php

// Show all information, defaults to INFO_ALL
echo phpinfo();

// Show just the module information.
// phpinfo(8) yields identical results.
phpinfo(INFO_MODULES);

?>