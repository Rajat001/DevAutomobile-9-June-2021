<!DOCTYPE html>
<html>
<head>
    <title></title>

<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

    <style>
.body{
    display: none;
}

@media print {
.body {
display: block;
}
}
</style>

</head>

<!--
<body class="body" onload="gatepass_receipt()">
-->
<body>
<div class="container" style="width: 1322px;">
   <br>
    
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default" style="border-color: #4e73df;">
                
                <div class="panel-body">
                    <div class="table-responsive">
<table class="table table-condensed">
                            
                        <!-- Section For Adding Starts-->    
            <thead>

            <tr style="color: white; font-size: 21px; background-color: black;">
            <td style="border: 1px solid black;" colspan="13"> 
            
            
            <strong style="margin-left: 536px;">
            DELIVERY RECEIPT
            </strong>
            
            
            <strong style="margin-left: 300px;">
            Mob.: 93196 26386
            </strong>
            
            </td>
            </tr>



<tr>
<td colspan="13" style="border: 1px solid black;" > 

<img src="tvs-logo.jpg" width="200px" height="140px">    
    
<span style="font-size: 70px; font-weight: 900; margin-left: 105px;"> 
DEV AUTOMOBILES

<br>

<p style="font-size: 28px; margin-left: 451px; margin-top: -50px;">( A Unit Of Dev Trading Co )</p>
 </span>

</td>
</tr>


<tr>
<td colspan="13" style="border: 1px solid black;" class="text-center"> 
<span style="font-size: 20px; font-weight: 800; margin-left: 60px;"> 
#91 Plot No 7, Main Road, Near Masjid, Mandawali, Delhi - 110092
</span>
</td>
</tr>


            </thead>
                        <!-- Section For Adding End-->
                            <thead>
                                <tr>
                                    <td colspan="2" style="border: 1px solid black;"><strong style="font-size: 18px; font-weight: 800;"> Receipt No. :- ___________ </strong></td>
                                    
                                    <td  colspan="7" style="border: 1px solid black; border-right-style: hidden;" class="text-right"></td>
                                    <td colspan="4" style="border: 1px solid black; " class="text-right"> 
                                    <span style="font-size: 18px; font-weight: 800; margin-right: 20px; border-left-style: hidden;">    
                                        Date :- _______________
                                    </span>
                                    </td>
                                </tr>
                            </thead>
                            <tbody>
                                
<!--
                                <tr>
                                    <td style="border: 1px solid black;" colspan="1"> Hello </td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td colspan="1"> Hello Mr.</td>
                                    <td style="border: 1px solid black;" colspan="1"> Hello </td>
                                </tr>
                            -->

                                <tr>
                                <td colspan="13" style="border: 1px solid black;" class="text-center"> 
                                    <span style="font-size: 22px; font-weight: 800; margin-left: 60px;"> Received with DEV AUTOMOBILES, New Delhi </span>
                                </td>
                                </tr>

                                
                                <tr><td></td></tr>
                                <tr>
                                <td colspan="13" style="border: 1px solid black; font-size: 24px;">
                                One Brand New _________ Bearing the following particulars in perfect Order and good condition . Tools and equipments completed as supplied by the manufacture.
                                </td>   
                                </tr>



                          
                                <tr>
                                    
                                <td colspan="7" style="border: 1px solid black; font-size: 24px;">
                                
                                Mode ______________________
                                <br>
                                Cash Receipt No. ______________
                                <br>
                                Financed by _____________
                                <br>
                                Engine No. ______________
                                <br>
                                Service Book No. ______________
                                </td>
                                <td colspan="6" style="border: 1px solid black; font-size: 24px;">
                                
                                Cost ______________________
                                <br>
                                Amount ______________
                                <br>
                                Balance Amount ______________
                                <br>
                                Chasis No. ______________
                                <br>
                                Colour ______________
                                </td>   
                                
                                </tr>

                                <tr><td></td></tr>

                                <tr>
                                    
                                <td colspan="7" style="border: 1px solid black; font-size: 24px;">
                                
                                <p style="text-align: center;"> <strong> <u>ITEMS</u> </strong>  </p>
                                Items Short Supplied ______________________
                                <br>
                                Delivery ____________ Km.
                                <br>
                                Date _____________
                                <br><br>
                                
                                <p style="text-align: center;"> <strong><u> OLD EXCHANGE</u> </strong>  </p>
                                
                                Vehicle Name.  ______________
                                <br>
                                Vehicle No.  ______________
                                <br><br>
                                <p style="text-align: center;"> <strong><u> SALES MANAGER</u> </strong>  </p>
                                Name. _____________
                                </td>
                                
                                <td colspan="6" style="border: 1px solid black; font-size: 24px;">
                                 <p style="text-align: center;"> <strong><u> DOCUMENTS / TOOLS</u> </strong>  </p>
                                <p style="font-weight: 700;">Owner's Manual with Service Book</p>
                                <p style="font-weight: 700;">Invoice, Insurance Cover Note,</p>    
                                <p style="font-weight: 700;">Registration Slip, One Tool Kit </p>
                                <p style="font-weight: 700;">Ex-showroom Room, New Delhi</p>
                                <p style="font-weight: 700;">Signature __________</p>

                                <br>
                                 Name. ______________________
                                <br>
                                Address. ____________________
                                <br><br>
                                
                                <p style="font-weight: 700;">Party's TIN</p>
                                </td>   
                                </tr>


<tr style="border: 1px solid black; font-size: 24px;">
    

<td colspan="13">

 <span style="font-size: 22px; font-weight: 800; margin-left: 245px; "> Vehicle Taken Delivery Without Reg. No. Customers Fully Own Risk
</span>

</td>   

</tr>

                         </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>


<script> 
function gatepass_receipt() {
  window.print();
}
</script>
</html>